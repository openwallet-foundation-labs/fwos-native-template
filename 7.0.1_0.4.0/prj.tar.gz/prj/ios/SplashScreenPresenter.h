#import <Foundation/Foundation.h>
#import <MendixNative.h>

@interface SplashScreenPresenter : NSObject<SplashScreenPresenterProtocol>
@end
